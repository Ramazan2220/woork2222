# 🪟 ИНСТРУКЦИЯ ПО РАЗВЕРТЫВАНИЮ НА WINDOWS VDS

## 1. СИСТЕМНЫЕ ТРЕБОВАНИЯ
- Windows Server 2019/2022 или Windows 10/11
- Python 3.9+ (рекомендуется 3.11)
- 2GB RAM минимум
- 20GB свободного места

## 2. УСТАНОВКА PYTHON

### Скачайте и установите Python:
1. Перейдите на https://www.python.org/downloads/windows/
2. Скачайте Python 3.11+ (64-bit)
3. При установке ОБЯЗАТЕЛЬНО поставьте галочку "Add Python to PATH"
4. Выберите "Install for all users"

### Проверка установки:
```cmd
python --version
pip --version
```

## 3. РАЗВЕРТЫВАНИЕ

### Распаковка:
1. Распакуйте архив instagram_bot_windows_vds.zip
2. Откройте папку instagram_bot
3. Запустите PowerShell или Command Prompt от имени администратора

### Быстрая установка:
```cmd
# Перейдите в папку с ботом
cd C:\path	o\instagram_bot

# Запустите автоматическую установку
quick_deploy.bat
```

## 4. РУЧНАЯ УСТАНОВКА (если автоматическая не работает)

### Создание виртуального окружения:
```cmd
python -m venv bot_env
bot_env\Scriptsctivate
```

### Установка зависимостей:
```cmd
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Создание .env файла:
```cmd
copy .env.example .env
notepad .env
```

### Настройте переменные в .env:
```env
TELEGRAM_BOT_TOKEN=ваш_токен_бота
ENCRYPTION_KEY=ваш_32_символьный_ключ
DATABASE_URL=sqlite:///data/database.db
```

### Инициализация базы данных:
```cmd
python -c "from database.db_manager import init_database; init_database()"
```

## 5. ЗАПУСК

### Тестовый запуск:
```cmd
python main.py
```

### Запуск как Windows Service:
```cmd
# Установка службы
install_service.bat

# Запуск службы
start_service.bat

# Остановка службы
stop_service.bat
```

## 6. УПРАВЛЕНИЕ

### Запуск бота:
- Двойной клик на `start_bot.bat`
- Или через командную строку: `start_bot.bat`

### Остановка бота:
- Закрыть окно консоли
- Или через диспетчер задач

### Просмотр логов:
- Двойной клик на `view_logs.bat`
- Файлы логов в папке `data/logs/`

## 7. АВТОЗАПУСК

### Через планировщик заданий:
1. Откройте "Планировщик заданий" (Task Scheduler)
2. Создайте простую задачу
3. Имя: "Instagram Bot"
4. Триггер: "При запуске компьютера"
5. Действие: Запуск программы
6. Программа: `C:\path	o\instagram_bot\start_service.bat`

### Через автозагрузку:
1. Win+R, введите `shell:startup`
2. Скопируйте туда ярлык на `start_bot.bat`

## 8. FIREWALL

### Настройка Windows Firewall:
1. Откройте "Брандмауэр Windows"
2. Разрешите Python через firewall
3. Если нужен веб-интерфейс, откройте порты 80/443

### PowerShell команды:
```powershell
# Разрешить Python
New-NetFirewallRule -DisplayName "Python" -Direction Inbound -Program "python.exe" -Action Allow

# Открыть порты (если нужно)
New-NetFirewallRule -DisplayName "HTTP" -Direction Inbound -Protocol TCP -LocalPort 80 -Action Allow
New-NetFirewallRule -DisplayName "HTTPS" -Direction Inbound -Protocol TCP -LocalPort 443 -Action Allow
```

## 9. МОНИТОРИНГ

### Диспетчер задач:
- Ctrl+Shift+Esc
- Найдите процесс python.exe
- Проверьте использование CPU/RAM

### Логи:
```cmd
# Просмотр логов
type data\logsot.log

# Логи в реальном времени
tail -f data\logsot.log  # если установлен Git Bash
```

## 10. BACKUP

### Создание backup:
```cmd
# Ручной backup
backup.bat

# Автоматический backup через планировщик
# Создайте задачу на ежедневный запуск backup.bat
```

## 11. РЕШЕНИЕ ПРОБЛЕМ

### Python не найден:
1. Переустановите Python с галочкой "Add to PATH"
2. Перезагрузите компьютер
3. Проверьте переменную PATH в системе

### Ошибки pip:
```cmd
python -m pip install --upgrade pip
python -m pip install --force-reinstall -r requirements.txt
```

### Проблемы с правами:
1. Запускайте от имени администратора
2. Переместите бота в C:\Instagram_Bot3. Дайте полные права на папку

### Кодировка в консоли:
```cmd
chcp 65001  # UTF-8
```

## 12. ПОЛЕЗНЫЕ КОМАНДЫ

```cmd
# Проверка процессов
tasklist | findstr python

# Завершение процесса
taskkill /f /im python.exe

# Проверка портов
netstat -an | findstr :80

# Системная информация
systeminfo

# Использование диска
dir /s
```

## 🎯 РЕКОМЕНДАЦИИ ДЛЯ WINDOWS VDS

### Лучшие провайдеры Windows VDS:
- **Timeweb** - Windows Server 2019/2022
- **REG.RU** - хорошая поддержка
- **Selectel** - профессиональные решения
- **Azure/AWS** - для enterprise

### Оптимальная конфигурация:
- **ОС:** Windows Server 2022
- **CPU:** 2-4 ядра
- **RAM:** 4GB
- **Диск:** 40GB SSD

## ⚠️ ВАЖНЫЕ ОСОБЕННОСТИ WINDOWS

1. **Пути файлов:** Используйте обратные слеши `\`
2. **Права:** Всегда запускайте от администратора
3. **Firewall:** Не забудьте настроить исключения
4. **Кодировка:** Установите UTF-8 в консоли
5. **Автозапуск:** Лучше через службу Windows

## 🔧 ПОСЛЕ УСТАНОВКИ

- [ ] Python установлен и в PATH
- [ ] Бот запускается без ошибок
- [ ] Настроен .env файл
- [ ] Добавлен первый аккаунт
- [ ] Настроен автозапуск
- [ ] Настроен firewall
- [ ] Проверены логи
