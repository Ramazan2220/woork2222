# 🚀 ИНСТРУКЦИЯ ПО РАЗВЕРТЫВАНИЮ НА VDS

## 1. СИСТЕМНЫЕ ТРЕБОВАНИЯ
- Ubuntu 20.04+ / CentOS 8+ / Debian 11+
- Python 3.9+
- 2GB RAM минимум
- 10GB свободного места

## 2. УСТАНОВКА ЗАВИСИМОСТЕЙ

### Ubuntu/Debian:
```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv git sqlite3
sudo apt install -y python3-dev build-essential
```

### CentOS/RHEL:
```bash
sudo yum update -y
sudo yum install -y python3 python3-pip git sqlite
sudo yum groupinstall -y "Development Tools"
```

## 3. РАЗВЕРТЫВАНИЕ

### Распаковка:
```bash
tar -xzf instagram_bot_vds.tar.gz
cd instagram_bot
```

### Создание виртуального окружения:
```bash
python3 -m venv bot_env
source bot_env/bin/activate
```

### Установка зависимостей:
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

## 4. НАСТРОЙКА

### Настройка .env файла:
```bash
nano .env
```

### Заполните переменные:
- TELEGRAM_BOT_TOKEN=ваш_токен
- ENCRYPTION_KEY=ваш_ключ_шифрования
- DATABASE_URL=sqlite:///data/database.db

### Инициализация базы данных:
```bash
python -c "from database.db_manager import init_database; init_database()"
```

## 5. ЗАПУСК

### Тестовый запуск:
```bash
python main.py
```

### Запуск как сервис (systemd):
```bash
sudo cp deployment/instagram_bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable instagram_bot
sudo systemctl start instagram_bot
```

### Проверка статуса:
```bash
sudo systemctl status instagram_bot
sudo journalctl -u instagram_bot -f
```

## 6. НАСТРОЙКА FIREWALL

```bash
# Открываем нужные порты
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP (если есть веб-интерфейс)
sudo ufw allow 443/tcp   # HTTPS
sudo ufw enable
```

## 7. МОНИТОРИНГ

### Логи:
```bash
tail -f data/logs/bot.log
tail -f data/logs/telegram_errors.log
```

### Системные ресурсы:
```bash
htop
df -h
free -h
```

## 8. BACKUP

### Создание бэкапа:
```bash
tar -czf backup_$(date +%Y%m%d_%H%M%S).tar.gz data/ .env
```

### Автоматический бэкап (cron):
```bash
# Добавить в crontab:
0 2 * * * cd /path/to/bot && tar -czf backup_$(date +\%Y\%m\%d).tar.gz data/ .env
```

## 9. ОБНОВЛЕНИЕ

```bash
# Остановка
sudo systemctl stop instagram_bot

# Бэкап
tar -czf backup_before_update.tar.gz data/ .env

# Обновление кода
git pull  # или загрузка нового архива

# Обновление зависимостей
source bot_env/bin/activate
pip install -r requirements.txt

# Запуск
sudo systemctl start instagram_bot
```

## 10. РЕШЕНИЕ ПРОБЛЕМ

### Проблемы с правами:
```bash
sudo chown -R $USER:$USER /path/to/bot
chmod +x main.py
```

### Проблемы с зависимостями:
```bash
pip install --force-reinstall -r requirements.txt
```

### Очистка логов:
```bash
find data/logs/ -name "*.log" -mtime +7 -delete
```
