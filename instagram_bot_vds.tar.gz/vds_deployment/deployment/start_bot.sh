#!/bin/bash
# Скрипт автозапуска бота

BOT_DIR="/home/ubuntu/instagram_bot"
cd $BOT_DIR

# Активируем виртуальное окружение
source bot_env/bin/activate

# Запускаем бота
python main.py
