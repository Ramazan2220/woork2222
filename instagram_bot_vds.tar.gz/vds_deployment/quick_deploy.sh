#!/bin/bash
# 🚀 Быстрое развертывание Instagram Bot на VDS
# Использование: ./quick_deploy.sh

set -e  # Остановка при ошибке

echo "🚀 БЫСТРОЕ РАЗВЕРТЫВАНИЕ INSTAGRAM BOT"
echo "====================================="

# Функция для логов
log() {
    echo "✅ $1"
}

error() {
    echo "❌ $1"
    exit 1
}

# 1. Проверка системы
log "Проверка системы..."
if ! command -v python3 &> /dev/null; then
    error "Python3 не установлен! Установите его сначала."
fi

# 2. Установка зависимостей (если нужно)
if ! command -v pip3 &> /dev/null; then
    log "Установка pip3..."
    sudo apt update
    sudo apt install -y python3-pip
fi

# 3. Установка системных зависимостей
log "Установка системных зависимостей..."
sudo apt install -y python3-venv python3-dev build-essential sqlite3 git

# 4. Создание виртуального окружения
log "Создание виртуального окружения..."
python3 -m venv bot_env
source bot_env/bin/activate

# 5. Установка Python зависимостей
log "Установка Python зависимостей..."
pip install --upgrade pip
pip install -r requirements.txt

# 6. Создание .env файла (если не существует)
if [ ! -f .env ]; then
    log "Создание .env файла..."
    cat > .env << 'EOF'
# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN_HERE

# Database Configuration
DATABASE_URL=sqlite:///data/database.db

# Encryption Key (сгенерируйте свой)
ENCRYPTION_KEY=YOUR_32_CHAR_ENCRYPTION_KEY_HERE

# Debug Mode
DEBUG=False

# Logging Level
LOG_LEVEL=INFO

# Instagram API Settings
INSTAGRAM_API_DELAY_MIN=1
INSTAGRAM_API_DELAY_MAX=3
EOF
    
    echo "⚠️  ВАЖНО: Отредактируйте .env файл с вашими настройками!"
    echo "nano .env"
fi

# 7. Создание директорий
log "Создание необходимых директорий..."
mkdir -p data/logs
mkdir -p data/accounts
mkdir -p data/media

# 8. Инициализация базы данных
log "Инициализация базы данных..."
python -c "from database.db_manager import init_database; init_database()" || true

# 9. Настройка systemd сервиса
log "Настройка systemd сервиса..."
USER_NAME=$(whoami)
CURRENT_DIR=$(pwd)

sudo tee /etc/systemd/system/instagram_bot.service > /dev/null << EOF
[Unit]
Description=Instagram Telegram Bot
After=network.target

[Service]
Type=simple
User=$USER_NAME
WorkingDirectory=$CURRENT_DIR
Environment=PATH=$CURRENT_DIR/bot_env/bin
ExecStart=$CURRENT_DIR/bot_env/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# 10. Запуск сервиса
log "Настройка автозапуска..."
sudo systemctl daemon-reload
sudo systemctl enable instagram_bot

# 11. Создание скриптов управления
log "Создание скриптов управления..."

# Скрипт запуска
cat > start_bot.sh << 'EOF'
#!/bin/bash
sudo systemctl start instagram_bot
echo "🚀 Бот запущен!"
EOF
chmod +x start_bot.sh

# Скрипт остановки
cat > stop_bot.sh << 'EOF'
#!/bin/bash
sudo systemctl stop instagram_bot
echo "🛑 Бот остановлен!"
EOF
chmod +x stop_bot.sh

# Скрипт статуса
cat > status_bot.sh << 'EOF'
#!/bin/bash
echo "📊 СТАТУС БОТА:"
sudo systemctl status instagram_bot --no-pager -l

echo -e "\n📋 ПОСЛЕДНИЕ ЛОГИ:"
sudo journalctl -u instagram_bot -n 20 --no-pager
EOF
chmod +x status_bot.sh

# Скрипт просмотра логов
cat > logs_bot.sh << 'EOF'
#!/bin/bash
echo "📋 ЛОГИ БОТА (Ctrl+C для выхода):"
sudo journalctl -u instagram_bot -f
EOF
chmod +x logs_bot.sh

# 12. Настройка firewall (базовая)
log "Настройка firewall..."
if command -v ufw &> /dev/null; then
    sudo ufw allow ssh
    sudo ufw --force enable
fi

echo ""
echo "🎉 РАЗВЕРТЫВАНИЕ ЗАВЕРШЕНО!"
echo "=========================="
echo ""
echo "📋 СЛЕДУЮЩИЕ ШАГИ:"
echo "1. Отредактируйте .env файл: nano .env"
echo "2. Запустите бота: ./start_bot.sh"
echo "3. Проверьте статус: ./status_bot.sh"
echo "4. Просмотр логов: ./logs_bot.sh"
echo ""
echo "🔧 УПРАВЛЕНИЕ:"
echo "• Запуск: ./start_bot.sh"
echo "• Остановка: ./stop_bot.sh"
echo "• Статус: ./status_bot.sh"
echo "• Логи: ./logs_bot.sh"
echo ""
echo "⚠️  НЕ ЗАБУДЬТЕ:"
echo "• Настроить TELEGRAM_BOT_TOKEN в .env"
echo "• Настроить ENCRYPTION_KEY в .env"
echo "• Добавить аккаунты Instagram через бота"
echo "" 