# Создайте файл __init__.py
echo '# Session Manager Module for InstaBot2.0